package assingment_2;

public interface Interface1 {
	
	public void welcome();
		
	public void printdetails();	
	public void setid(String id);

}
