package assingment_2;

public interface Interface2 {

	
	public void print();
	
	public void access();
}
